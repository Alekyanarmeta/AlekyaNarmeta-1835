function Beauty()
{
    return <h1>this is men page</h1>
}
export default Beauty