import "./App.css"
function Header()
{
    return(
        <div className="head">
            <h3>TrendyCart</h3>
        </div>
    )
}
export default Header